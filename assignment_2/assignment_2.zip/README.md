# Assignment 2: Monte Carlo Racetrack

## Instructions
* Make sure your working directory is the "assignment_2" directory with the `pwd` command.
* Run the script `racetrack.py` with `python racetrack.py`.
* There are no other arguments. This will recreate the results in the report. 

## Dependencies
The only dependencies outside of the Python Standard Library are as follows:
* numpy
* matplotlib